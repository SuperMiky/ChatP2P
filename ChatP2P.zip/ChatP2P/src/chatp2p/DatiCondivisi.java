/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatp2p;

import java.net.UnknownHostException;

/**
 *
 * @author Miky
 */
public class DatiCondivisi {

    Grafica g = new Grafica();
    private Client c;
    private static boolean connesso; //per vedere se c'è già un peer connesso

    public DatiCondivisi() {
        c = new Client();
        connesso = false;
    }
    
    public void elabora(String messaggio) throws UnknownHostException
    {
        String[] mess = CSV.Splitta(messaggio);
        if(mess[0].equals("c"))
        {
            c.Connessione(mess[1]); //chiamo il metodo del client per la connessione passando il nome del mittente
        }
        
        else if(mess[0].equals("y")) //il destinatario ha accettato la connessione
        {
            setConnesso(true); //è connesso
            g.OkConn(mess[1]); //chiamo il metodo della grafica che visualizzera il nome del mittente     
        }
        
        else if(mess[0].equals("m"))
        {
            g.VisMess(mess[1]); //chiamo il metodo della grafica per visualizzare il messaggio
        }
    }

    public static boolean isConnesso() {
        return connesso;
    }

    public void setConnesso(boolean connesso) {
        DatiCondivisi.connesso = connesso;
    }
}
