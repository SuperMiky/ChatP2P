/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatp2p;

import java.awt.Component;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import javax.swing.JOptionPane;

/**
 *
 * @author Miky
 */
public class Client extends Thread {
    
    Grafica g = new Grafica();
    private String nome;
    private DatagramSocket socket;
    private InetAddress address;
    private byte[] buffer;

    public Client() {} //costruttore vuoto
      
    public void InviaPacchetto(String riga) throws UnknownHostException
    {
        try {
            socket = new DatagramSocket();
            address = InetAddress.getByName("192.168.7.18");
        }catch (SocketException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        buffer = riga.getBytes();
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, address, 666);
        try {
            socket.send(packet);
        }catch (IOException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }
    
    public void Connessione(String nomeMitt) throws UnknownHostException
    {
        DatiCondivisi d = new DatiCondivisi();
        g.MessConnessione(d, nomeMitt); //chiamo il metodo della grafica che mostra il mess per la connessione
    }
}
